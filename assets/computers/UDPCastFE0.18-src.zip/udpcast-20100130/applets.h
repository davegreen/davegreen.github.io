IF_UDPRECEIVER(APPLET_ODDNAME(udp-receiver, udp_receiver, _BB_DIR_USR_SBIN, _BB_SUID_DROP, udp_receiver))
IF_UDPSENDER(APPLET_ODDNAME(udp-sender, udp_sender, _BB_DIR_USR_SBIN, _BB_SUID_DROP, udp_receiver))
