=== WP-AlterHowdy ===
Contributors:      greeniegreen
Plugin Name:       WP-AlterHowdy
Plugin URI:        http://tookitaway.co.uk/
Tags:              toolbar-appearance, toolbar, admin-bar, howdy, replace howdy, remove howdy
Requires at least: 3.3
Tested up to:      3.3
Stable tag:        0.0.1
Version:           0.0.1

This plugin changes the 'Howdy, user' welcome in the 
toolbar to a setting you specify. That's it.

== Description ==

This plugin changes the 'Howdy, user' welcome in the
toolbar to a setting you specify. That's it.

You can specify the welcome to use on the settings page.

This plugin probably isn't the bwst way to do this.
However, it appears to be the most straightforward way
to alter the 'Howdy, user' message that appears in the toolbar.

== Installation ==

Install the plugin in the normal manner.
Activate the plugin in the plugins menu.
Set your welcome message in the plugin settings page.

== Changelog ==

= 0.0.1 =
* The code.