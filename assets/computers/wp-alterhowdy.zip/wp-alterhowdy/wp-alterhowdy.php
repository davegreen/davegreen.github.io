<?php
/*
  Plugin Name: WP-AlterHowdy
  Plugin URI:  http://tookitaway.co.uk/
  Description: Alters the 'Howdy, user' welcome in the toolbar to a setting you specify. That's it.
  Version:     0.0.1
  Author:      Dave Green
  Author URI:  http://tookitaway.co.uk/about/
  License:     WTFPL

  Copyright 2012 Dave Green (email: david.green@tookitaway.co.uk)

  This program is free software. It comes without any warranty, to
  the extent permitted by applicable law. You can redistribute it
  and/or modify it under the terms of the Do What The Fuck You Want
  To Public License, Version 2, as published by Sam Hocevar. See
  http://sam.zoy.org/wtfpl/COPYING for more details.
*/

// Replace the 'admin_bar_menu' with our own.
add_action('init','replace_admin_bar_menu');

// Adds the action for the plugin admin menu.
add_action('admin_menu', 'alterhowdy_menu');

add_action('admin_init', 'plugin_admin_init');

function plugin_admin_init(){
  register_setting('alterhowdy_options', 'alterhowdy_options', 'alterhowdy_options_validate');
  add_settings_section('alterhowdy_main', 'Main Settings', 'alterhowdy_text', 'alterhowdy');
  add_settings_field('alterhowdy_name', 'Greeting:', 'alterhowdy_input', 'alterhowdy', 'alterhowdy_main');
}

function alterhowdy_text() {
echo '<p>Main settings for the WP-AlterHowdy plugin.</p>';
}

function alterhowdy_input() {
  $options = get_option('alterhowdy_options');
  echo "<input id='alterhowdy_name' name='alterhowdy_options[text_string]' size='30' type='text' value='{$options['text_string']}' />";
}

function replace_admin_bar_menu() {
  // Removes admin_bar_menu action, so we can replace it with our own.
  remove_action('admin_bar_menu', 'wp_admin_bar_my_account_item', 7);
  
  // Add our own action, to replace the previously removed action.
  add_action('admin_bar_menu', 'override_wp_admin_bar_my_account_item', 7);
}

// validate our options
function alterhowdy_options_validate($input) {
  $newinput['text_string'] = trim($input['text_string']);
  if(!preg_match('/^[a-z0-9]{1,32}?$/i', $newinput['text_string'])) {
    $newinput['text_string'] = '';
  }
  return $newinput;
}

// Adds the options page for the plugin.
function alterhowdy_menu() {
  add_options_page('Alter Howdy Options', 'WP-AlterHowdy', 'manage_options', 'alterhowdy', 'alterhowdy_options');
}

// The new admin bar data.
function override_wp_admin_bar_my_account_item($wp_admin_bar) {
  $options      = get_option('alterhowdy_options');
  $user_id      = get_current_user_id();
  $current_user = wp_get_current_user();
  $profile_url  = get_edit_profile_url($user_id);

  if (!$user_id)
    return;

  $avatar = get_avatar($user_id, 16);

  // Changed the 'Howdy' to 'Welcome'. Isn't that amazing!
  $howdy  = sprintf(__($options['text_string'] . ', %1$s'), $current_user->display_name);
  $class  = empty($avatar) ? '' : 'with-avatar';

  $wp_admin_bar->add_menu(array(
    'id'        => 'my-account',
    'parent'    => 'top-secondary',
    'title'     => $howdy . $avatar,
    'href'      => $profile_url,
    'meta'      => array(
      'class'     => $class,
      'title'     => __('My Account'),
    ),)
  );
}

// The options page for the plugin.
function alterhowdy_options() {
  if (!current_user_can('manage_options'))  {
    wp_die(__('You do not have sufficient permissions to access this page.'));
  }
  ?>
<div>
  <h2>WP-AlterHowdy</h2>
  <form action="options.php" method="post">
    <?php settings_fields('alterhowdy_options'); ?>
    <?php do_settings_sections('alterhowdy'); ?>
    <p class="submit">
      <input type="submit" name="submit" value="<?php esc_attr_e('Save Changes'); ?>" />
    </p>
  </form>
</div>
<?php
 
}

?>