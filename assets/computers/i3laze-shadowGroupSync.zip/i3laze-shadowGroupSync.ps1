#For logging, Run with: powershell.exe -file "c:\path\shadowGroupSync.ps1" | tee -file ('c:\path\log\shadowGroupSync-'+ (Get-Date -format d.M.yyyy) + '.log')
Import-Module ActiveDirectory

#Destination OU for shadow groups.
$destOU = "OU=Users,DC=contoso,DC=com"

#--CSV Format--
#Domain,SourceOU,GroupName
#contoso.com,"OU=A1,OU=A_Block,OU=Users,DC=contoso,DC=com",Block-A1
#contoso.com,"OU=A2,OU=A_Block,OU=Users,DC=contoso,DC=com",Block-A2
#contoso.com,"OU=B1,OU=B_Block,OU=Users,DC=contoso,DC=com",Block-B1
#child.contoso.com,"OU=Users,DC=child,DC=contoso,DC=com",Block-B2

#Full Path to the OU\Group CSV.
$csvfile = "c:\path\group_list.txt"
$csv = Import-Csv $csvfile

#Gets the PCs from the specified OU and returns the collection.
Function Get-PCs($searchbase)
{
  $computers = Get-ADComputer -Filter {name -like '*'} -SearchBase $searchbase -SearchScope 2 -server $domain -Properties DistinguishedName
  return $computers
}
Function Get-Users($searchbase, $domain)
{
  $users = Get-ADUser -Filter {EmailAddress -like '*' -and Enabled -eq $True -and name -notlike '*test*'} -SearchBase $searchbase -SearchScope 2 -server $domain -Properties DistinguishedName
  return $users  
}

#Gets the members from the shadow group. If the group does not exist, create it.
Function Get-ShadowGroupMembers($groupname)
{
  if (!(Get-ADGroup -Filter {SamAccountName -eq $groupname} -SearchBase $destou))
  {
    New-ADGroup -Name $groupname -SamAccountName $groupname -Path $destou -Groupcategory Security -GroupScope Universal
  }
  
  $groupmembers = Get-ADGroupMember -Identity $groupname
  return $groupmembers
}

#Adds the specified computer account to the group.
Function Add-ShadowGroupMember($domain, $group, $member)
{
 $globalmember = Get-ADUser $member -Server $domain
  Add-ADGroupMember -Identity $group -member $globalmember 
}

#Removes the specified computer account from the group.
Function Remove-ShadowGroupMember($domain, $group, $member)
{
 $globalmember = Get-ADUser $member -Server $domain
  Remove-ADGroupMember -Identity $group -member $globalmember -confirm:$false
}

#Iterate through the CSV and action each shadow group.
foreach ($cs in $csv)
{
  Write-Output ("--------------------------------------------------------")
  Write-Output ("")
  Write-Output ("Sync: " + ($cs.SourceOU))
  Write-Output ("To:   " + ($cs.GroupName))
  Write-Output ("")
  
  #Populate the two computer sets.
  #$pcs = Get-PCs $cs.SourceOU
  $pcs = Get-Users $cs.SourceOU $cs.Domain
  $groupmembers = Get-ShadowGroupMembers $cs.Groupname
  
  #If the group is empty, populate the group.
  if (!$groupmembers)
  {
    Write-Output ("Group """ + ($cs.GroupName) + """ is empty")
    foreach ($pc in $pcs)
    {
      Write-Output ("Adding " + $pc.Name)
      Add-ShadowGroupMember $cs.Domain $cs.GroupName $pc.SAMAccountName
    }
  }
  
  #If the group has members, get the group members to mirror the OU contents.
  else
  {
    switch (Compare-Object -ReferenceObject $groupmembers -DifferenceObject $pcs -property SAMAccountName, Name)
    {
      {$_.SideIndicator -eq "=>"}
      {
        Write-Output ("Adding   " + ($_.Name))
        Add-ShadowGroupMember $cs.Domain $cs.GroupName $_.SAMAccountName
      }
      
      {$_.SideIndicator -eq "<="} 
      {
        Write-Output ("Removing " + ($_.Name))
        Remove-ShadowGroupMember $cs.Domain $cs.GroupName $_.SAMAccountName
      }
    }
  }
  
  Write-Output ("Sync for """ + ($cs.GroupName) + """ complete!")
  Write-Output ("")
}