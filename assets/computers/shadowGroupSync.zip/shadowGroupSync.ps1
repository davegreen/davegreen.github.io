#For logging, Run with powershell.exe -command &{C:\Path\to\shadowGroupSync.ps1 2>&1 | tee -filePath ('C:\Path\to\log\shadowGroupSync-' + (Get-Date -format d.M.yyyy) + '.log')}
Import-Module ActiveDirectory

#Destination OU for shadow groups.
$destOU = "OU=Computers,OU=Groups,DC=domain,DC=local"

#--CSV Format--

#SourceOU,GroupName
#"OU=A1,OU=A Block,OU=Workstations,DC=domain,DC=local",A Block-A1
#"OU=A2,OU=A Block,OU=Workstations,DC=domain,DC=local",A Block-A2
#"OU=B1,OU=B Block,OU=Workstations,DC=domain,DC=local",B Block-B1
#"OU=B2,OU=B Block,OU=Workstations,DC=domain,DC=local",B Block-B2

#Full Path to the OU\Group CSV.
$csvfile = "ShadowGroups(SAMPLE).csv"
$csv = Import-Csv $csvfile

#Gets the PCs from the specified OU and returns the collection.
Function Get-PCs($searchbase)
{
  $computers = Get-ADComputer -Filter 'name -like "*"' -SearchBase $searchbase -SearchScope 2 -Properties DistinguishedName
  return $computers
}

#Gets the members from the shadow group. If the group does not exist, create it.
Function Get-ShadowGroupMembers($groupname)
{
  if (!(Get-ADGroup -Filter {SamAccountName -eq $groupname} -SearchBase $destou))
  {
    New-ADGroup -Name $groupname -SamAccountName $groupname -Path $destou -Groupcategory Security -GroupScope Global
  }
  
  $groupmembers = Get-ADGroupMember -Identity $groupname
  return $groupmembers
}

#Adds the specified computer account to the group.
Function Add-ShadowGroupMember($group, $member)
{
  Add-ADGroupMember -Identity $group -member $member
}

#Removes the specified computer account from the group.
Function Remove-ShadowGroupMember($group, $member)
{
  Remove-ADGroupMember -Identity $group -member $member -confirm:$false
}

#Iterate through the CSV and action each shadow group.
foreach ($cs in $csv)
{
  Write-Output ("")
  Write-Output ("Sync: " + ($cs.SourceOU))
  Write-Output ("To:   " + ($cs.GroupName))
  Write-Output ("")
  
  #Populate the two computer sets.
  $pcs = Get-PCs $cs.SourceOU
  $groupmembers = Get-ShadowGroupMembers $cs.Groupname
  
  #If the group is empty, populate the group.
  if (!$groupmembers)
  {
    Write-Output (($cs.GroupName) + " is empty")
    foreach ($pc in $pcs)
    {
      Write-Output ("Adding " + $pc.Name)
      Add-ShadowGroupMember $cs.GroupName $pc.SAMAccountName
    }
  }
  
  #If the group has members, get the group members to mirror the OU contents.
  else
  {
    switch (Compare-Object -ReferenceObject $groupmembers -DifferenceObject $pcs -property SAMAccountName, Name)
    {
      {$_.SideIndicator -eq "=>"}
      {
        Write-Output ("Adding   " + ($_.Name))
        Add-ShadowGroupMember $cs.GroupName $_.SAMAccountName
      }
      
      {$_.SideIndicator -eq "<="} 
      {
        Write-Output ("Removing " + ($_.Name))
        Remove-ShadowGroupMember $cs.GroupName $_.SAMAccountName
      }
    }
  }
  
  Write-Output ("")
  Write-Output ("Sync for " + ($cs.GroupName) + " complete!")
}